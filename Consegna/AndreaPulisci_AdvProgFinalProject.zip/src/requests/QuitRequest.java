package requests;

public class QuitRequest implements Request {
    public QuitRequest() {

    }

    @Override
    public String call() {
        return null;
    }
}
