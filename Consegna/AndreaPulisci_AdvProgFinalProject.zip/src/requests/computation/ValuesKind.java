package requests.computation;

public enum ValuesKind {
    GRID, LIST
}

