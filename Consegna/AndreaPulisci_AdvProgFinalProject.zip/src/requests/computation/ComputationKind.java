package requests.computation;

public enum ComputationKind {
    MIN, MAX, AVG, COUNT
}
